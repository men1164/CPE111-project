/*
 * Created by Wagee Jr. Nanta Aree (Zor) 62070503445
 * modify mood and keywords
 */

#ifndef modifyMood_h
#define modifyMood_h

#define MAXKEYWORDS 40

void modifyMood();
void addMood();
void deleteMood();
void adjustKeyword();
void addKeyword(char mood[]);
void deleteKeyword(char mood[]);

#endif /* modifyMood_h */
